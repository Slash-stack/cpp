#include "vecteur.hxx"

int main(){
  Vecteur v1;
  Vecteur v2;
  ....
  std::cout<<v1<<std::endl;
  std::cout<<v2<<std::endl;

  return EXIT_SUCCESS;
}